﻿using UnityEngine;
using System.Collections;

public class PlayerControls : MonoBehaviour {
	public int m_PlayerNumber = 1;         
	public float m_Speed = 12f;            
	public float m_TurnSpeed = 180f;       


	private string m_MovementAxisName;     
	private string m_TurnAxisName;         
	private Rigidbody m_Rigidbody;         
	private float m_MovementInputValue;    
	private float m_TurnInputValue;               


	private void Awake()
	{
		m_Rigidbody = GetComponent<Rigidbody>();
	}


	private void OnEnable ()
	{
		m_Rigidbody.isKinematic = false;
		m_MovementInputValue = 0f;
		m_TurnInputValue = 0f;
	}


	private void OnDisable ()
	{
		m_Rigidbody.isKinematic = true;
	}


	private void Start()
	{
		m_MovementAxisName = "Vertical" + m_PlayerNumber;
		m_TurnAxisName = "Horizontal" + m_PlayerNumber;

	}

	private void Update()
	{
		// Store the player's input and make sure the audio for the engine is playing.
		m_MovementInputValue = Input.GetAxis(m_MovementAxisName);
		m_TurnInputValue = Input.GetAxis (m_TurnAxisName);

	}




	private void FixedUpdate()
	{
		// Move and turn the tank.
		Move();
		Turn ();
	}


	private void Move()
	{
		// Adjust the position of the tank based on the player's input.
		Vector3 movement = transform.up *m_MovementInputValue *m_Speed *Time.deltaTime;

		// Apply this movement to the rigidbody's position
		m_Rigidbody.MovePosition (m_Rigidbody.position + movement);
	}


	private void Turn()
	{
		// Adjust the rotation of the tank based on the player's input.
		float turn = m_TurnInputValue *m_TurnSpeed * Time.deltaTime;

		Quaternion turnRotation = Quaternion.Euler (0f, 0f, turn);

		m_Rigidbody.MoveRotation (m_Rigidbody.rotation * turnRotation);
	}
}
